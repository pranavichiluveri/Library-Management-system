/**
 * 
 */
/**
 * 
 */
package main;

import view.LoginFrame;
import dao.DBConnection;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        DBConnection.initialize();
        new LoginFrame();
    }
}

// Database Connection Class
package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/library";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static void initialize() {
        System.out.println("Database Connected Successfully");
    }
}

// Login GUI
package view;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginFrame() {
        setTitle("Library Management System - Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        
        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 50, 100, 30);
        add(userLabel);
        
        usernameField = new JTextField();
        usernameField.setBounds(150, 50, 200, 30);
        add(usernameField);
        
        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(50, 100, 100, 30);
        add(passLabel);
        
        passwordField = new JPasswordField();
        passwordField.setBounds(150, 100, 200, 30);
        add(passwordField);
        
        loginButton = new JButton("Login");
        loginButton.setBounds(150, 150, 100, 30);
        add(loginButton);
        
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (username.equals("admin") && password.equals("admin")) {
                    JOptionPane.showMessageDialog(null, "Login Successful");
                    new DashboardFrame();
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Credentials");
                }
            }
        });
        
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

// Dashboard GUI
package view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class DashboardFrame extends JFrame {
    public DashboardFrame() {
        setTitle("Library Dashboard");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 2));
        
        JButton bookBtn = new JButton("Manage Books");
        JButton userBtn = new JButton("Manage Users");
        JButton issueBtn = new JButton("Issue Books");
        JButton returnBtn = new JButton("Return Books");
        JButton searchBtn = new JButton("Search Books");
        
        add(bookBtn);
        add(userBtn);
        add(issueBtn);
        add(returnBtn);
        add(searchBtn);
        
        bookBtn.addActionListener(e -> new BookManagementFrame().setVisible(true));
        userBtn.addActionListener(e -> new UserManagementFrame().setVisible(true));
        issueBtn.addActionListener(e -> new IssueBookFrame().setVisible(true));
        returnBtn.addActionListener(e -> new ReturnBookFrame().setVisible(true));
        searchBtn.addActionListener(e -> new SearchBookFrame().setVisible(true));
        
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

// Book Management GUI
package view;
import javax.swing.*;

public class BookManagementFrame extends JFrame {
    public BookManagementFrame() {
        setTitle("Manage Books");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        JLabel label = new JLabel("Book Management Module");
        label.setBounds(100, 50, 200, 30);
        add(label);
        setLocationRelativeTo(null);
    }
}

// User Management GUI
package view;
import javax.swing.*;

public class UserManagementFrame extends JFrame {
    public UserManagementFrame() {
        setTitle("Manage Users");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        JLabel label = new JLabel("User Management Module");
        label.setBounds(100, 50, 200, 30);
        add(label);
        setLocationRelativeTo(null);
    }
}

// Issue Books GUI
package view;
import javax.swing.*;

public class IssueBookFrame extends JFrame {
    public IssueBookFrame() {
        setTitle("Issue Books");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        JLabel label = new JLabel("Issue Book Module");
        label.setBounds(100, 50, 200, 30);
        add(label);
        setLocationRelativeTo(null);
    }
}

// Return Books GUI
package view;
import javax.swing.*;

public class ReturnBookFrame extends JFrame {
    public ReturnBookFrame() {
        setTitle("Return Books");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        JLabel label = new JLabel("Return Book Module");
        label.setBounds(100, 50, 200, 30);
        add(label);
        setLocationRelativeTo(null);
    }
}

// Search Books GUI
package view;
import javax.swing.*;

public class SearchBookFrame extends JFrame {
    public SearchBookFrame() {
        setTitle("Search Books");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        JLabel label = new JLabel("Search Book Module");
        label.setBounds(100, 50, 200, 30);
        add(label);
        setLocationRelativeTo(null);
    }
}
